import React, { useState, useEffect } from 'react';

import commerce from '../../lib/Commerce';

const FilteredProductManager = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('');

  useEffect(() => {
    fetchProducts();
  });

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const response = await commerce.get('/products');
      const products = response.data;
      setProducts(products);
      setLoading(false);
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  const createProduct = async (productData) => {
    try {
      const response = await commerce.post('/products', productData);
      const newProduct = response.data;
      setProducts([...products, newProduct]);
    } catch (error) {
      setError(error.message);
    }
  };

  const updateProduct = async (productId, productData) => {
    try {
      const response = await commerce.put(`/products/${productId}`, productData);
      const updatedProduct = response.data;
      setProducts(products.map((product) => (product.id === productId? updatedProduct : product)));
    } catch (error) {
      setError(error.message);
    }
  };

  const deleteProduct = async (productId) => {
    try {
      await commerce.delete(`/products/${productId}`);
      setProducts(products.filter((product) => product.id!== productId));
    } catch (error) {
      setError(error.message);
    }
  };

  const handleCategoryChange = (event) => {
    setSelectedCategory(event.target.value);
  };

  const filteredProducts = selectedCategory
    ? products.filter((product) => product.category === selectedCategory)
    : products;

  return (
    <div>
      <h1>Product Manager</h1>
      <div>
        <label>
          Category:
          <select value={selectedCategory} onChange={handleCategoryChange}>
            <option value="">All</option>
            <option value="electronics">Electronics</option>
            <option value="clothing">Clothing</option>
            <option value="books">Books</option>
          </select>
        </label>
      </div>
      {loading? (
        <p>Loading...</p>
      ) : (
        <ul>
          {filteredProducts.map((product) => (
            <li key={product.id}>
              <h2>{product.name}</h2>
              <p>{product.description}</p>
              <p>Price: {product.price.formatted_with_symbol}</p>
              <button onClick={() => updateProduct(product.id, { name: 'Updated Product' })}>
                Update
              </button>
              <button onClick={() => deleteProduct(product.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form
        onSubmit={(event) => {
          event.preventDefault();
          const productData = {
            name: event.target.name.value,
            description: event.target.description.value,
            category: event.target.category.value,
            price: {
              amount: event.target.price.value,
              currency: 'USD',
            },
          };
          createProduct(productData);
        }}
      >
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Description:
          <input type="text" name="description" />
        </label>
        <br />
        <label>
          Category:
          <select name="category">
            <option value="electronics">Electronics</option>
            <option value="clothing">Clothing</option>
            <option value="books">Books</option>
          </select>
        </label>
        <br />
        <label>
          Price:
          <input type="number" name="price" />
        </label>
        <br />
        <button type="submit">Create Product</button>
      </form>
    </div>
  );
};

export default FilteredProductManager;